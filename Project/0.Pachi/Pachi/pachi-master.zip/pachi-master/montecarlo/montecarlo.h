#ifndef PACHI_MONTECARLO_MONTECARLO_H
#define PACHI_MONTECARLO_MONTECARLO_H

#include "engine.h"

struct engine *engine_montecarlo_init(char *arg, struct board *b);

#endif

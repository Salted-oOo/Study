#ifndef __RUN_H__
#define __RUN_H__ 1

void run(const char *program, const char *filein, const char *fileout);

#endif
